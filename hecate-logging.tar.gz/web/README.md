<h1 align='center'>Hecate UI</h1>

<p align=center>Default Hecate Web UI</p>

The Web UI can be found in it's compiled form in `dist/`

If you want to make changes or rebuild run the following:

```sh
yarn install
yarn build

## Run Hecate server
cd ../
cargo run
```
