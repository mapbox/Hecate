<template>
    <div class='flex-child px12 py12 bg-gray-faint round-b-ml txt-s flex-child'>
        <div align='center'><a href="https://github.com/ingalls/hecate">Powered By Hecate Server</a></div>
    </div>
</template>

<script>
export default {
    name: 'foot',
    render: h => h(App)
}
</script>
